#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from edx_dl import edx_dl

edx_dl.main()
