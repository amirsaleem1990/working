# priv=`wc -l *.txt | grep total | sed 's/total//g'`
# while :; do
# 	cur=`wc -l *.txt | grep total | sed 's/total//g'` 
# 	diff=$(( $(( $cur - $priv )) / 4))
# 	echo "$diff      $(date +%H:%M:%S)"
# 	priv=$cur
# 	sleep 60
# done

read -p "Enter name: " name
echo  `ls *$name*`
while :; do
	extracted=`grep https *$name*.txt | wc -l`
	total=`grep https ../Links.csv | grep $name | wc -l`
	diff=$(( $total - $extracted))
	echo "$diff   `date +%H:%M:%S`"
	sleep 60
done
