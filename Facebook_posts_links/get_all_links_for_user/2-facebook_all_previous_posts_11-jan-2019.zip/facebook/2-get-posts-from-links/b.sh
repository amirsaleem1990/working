# priv=`wc -l *.txt | grep total | sed 's/total//g'`
# while :; do
# 	cur=`wc -l *.txt | grep total | sed 's/total//g'` 
# 	balance=$(( $(( $cur - $priv )) / 4))
# 	echo "$balance      $(date +%H:%M:%S)"
# 	priv=$cur
# 	sleep 60
# done

convertsecs() {
 ((h=${1}/3600))
 ((m=(${1}%3600)/60))
 ((s=${1}%60))
 printf "%02d:%02d:%02d\n" $h $m $s
}

Average_array=()
Average_array+=("2")
ls *.txt  -lthr
echo -e "\n"
read -p "Enter name: " name
#name=munib.hussain86
echo "You are selected This:  `ls *$name*`"
completed=`grep https *$name*.txt | wc -l`
total=`grep https ../Links.csv | grep $name | wc -l`
while :; do
	extracted=`grep https *$name*.txt | wc -l`
	balance=$(( $total - $extracted ))

	completed_in_last_mint=$(( $extracted - $completed ))

	Average_array+=("$completed_in_last_mint")
	SUM=0
	for i in ${Average_array[@]}
	do
	  SUM=$(echo `expr $SUM + $i`)
	done

	LEN_OF_Average_array=$(echo "${#Average_array[@]}")
	mean=$(echo "scale=3; $SUM/$LEN_OF_Average_array" | bc)

	sleep_time=60
	Estimated_time=$(echo "scale=3; $balance/$mean*$sleep_time" | bc)
	Estimated_time=${Estimated_time%.*}
	# echo "*********************************************************"
	echo "Estimated time: `convertsecs $Estimated_time` |  Balance links: $balance  |  Current Time: `date +%H:%M` | Total Lines: `wc -l *.txt | grep total | sed 's/total//g' `"
	# echo "*********************************************************"
	# echo "
# balance  : $balance
# completd : $completed
# extracted: $extracted
# total    : $total
# completd_in_last_mint: $completed_in_last_mint
# SUM      : $SUM
# mean     : $mean" | sort
	completed=$extracted
	sleep $sleep_time

done

